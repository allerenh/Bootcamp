//
//  Task.swift
//  Reto3
//
//  Created by Ana Isabel Llerena Huayta on 2/12/22.
//

import Foundation

struct Task {
    
    let title: String?
    let description: String?
    let priority: String?
    
}
